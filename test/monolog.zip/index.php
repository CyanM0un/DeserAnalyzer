<?php
  
include_once __DIR__ . "/vendor/autoload.php";
unserialize(base64_decode($_GET['input']));

